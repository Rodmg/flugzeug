require("dotenv").config();
import { db } from "@/db";
import { getSwagger, getAuthorization } from "./decorators";
import path from "path";
import fs from "fs";
import YAML from "yaml";
import { config } from "@/config";
import {
  requetSchemaGenerator,
  responseSchemaGenerator,
  updateSchemaGenerator,
} from "./schemaGenerators";
import pathsGenerator from "./pathsGenerator";

const DOCUMENTATION_DIR = path.join(__dirname, "../../../app/documentation");

const sequelize = {
  models: db.models,
};

const models = sequelize.models;

// base estructure for open api schema
let openApiSchema = {
  openapi: "3.0.0",
  info: { title: "Docs", version: "1.0.0" },
  host: config.urls.url + ":" + config.urls.port,
  basePath: config.urls.apiRoot,
  servers: [
    {
      url:
        config.urls.protocol +
        "://" +
        config.urls.url +
        ":" +
        config.urls.port +
        config.urls.apiRoot,
      description: "server description",
    },
  ],
  paths: {},
  components: {
    schemas: {
      NotFound: {
        type: "object",
        properties: {
          message: {
            type: "string",
            example: "Not Found",
          },
        },
      },
      Unauthorized: {
        type: "object",
        properties: {
          message: {
            type: "string",
            example: "Unauthorized",
          },
          data: {
            type: "string",
            example: "No Token Present",
          },
        },
      },
    },
    securitySchemes: {
      bearerAuth: {
        type: "http",
        scheme: "bearer",
        bearerFormat: "JWT",
      },
    },
  },
  // security by bearerAuth is active globlaly by default
  security: [{ bearerAuth: [] }],
  tags: [],
};

//iterate all models registered in sequelize
for (const modelKey in models) {
  const model = models[modelKey];
  const documetModel = getSwagger(model);
  const authorizationOptions = getAuthorization(model);
  if (documetModel) {
    console.log("genarating documentation for : " + modelKey + ".....");

    //add model requestSchema
    openApiSchema.components.schemas[
      modelKey + "Request"
    ] = requetSchemaGenerator(model);
    //add model responseSchema
    openApiSchema.components.schemas[
      modelKey + "Response"
    ] = responseSchemaGenerator(model);
    //add model updateSceham
    openApiSchema.components.schemas[
      modelKey + "Update"
    ] = updateSchemaGenerator(model);

    //add base paths for model
    openApiSchema.paths = {
      ...openApiSchema.paths,
      ...pathsGenerator(modelKey, authorizationOptions),
    };
  }
}

//save documentation files
const doc = new YAML.Document();
doc.contents = openApiSchema;
fs.writeFileSync(
  path.join(DOCUMENTATION_DIR, "openApiSchema.json"),
  JSON.stringify(openApiSchema, null, 2),
);
fs.writeFileSync(
  path.join(DOCUMENTATION_DIR, "openApiSchema.yml"),
  doc.toString(),
);
