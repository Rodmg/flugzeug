import "reflect-metadata";

//classDecorator
//active Swager documentation for a Model
export function swagger(active: boolean = true) {
  return target => {
    Reflect.defineMetadata("swagger", active, target.prototype);
    return target;
  };
}

export type AuthorizationOptions = {
  get?: boolean;
  post?: boolean;
  put?: boolean;
  delete?: boolean;
};
//active or disable authorization for http methos in a Model
export function swaggerAuthorization(
  options: AuthorizationOptions = {
    get: true,
    post: true,
    put: true,
    delete: true,
  },
) {
  let initialState = {
    get: true,
    post: true,
    put: true,
    delete: true,
  };

  const authorizationOptions = {
    ...initialState,
    ...options,
  };

  return target => {
    Reflect.defineMetadata(
      "authorization",
      authorizationOptions,
      target.prototype,
    );
    return target;
  };
}

// property decorator
export function swaggerRequestNotRequired(target: any, propertyKey: string) {
  Reflect.defineMetadata("requestRequired", false, target, propertyKey);
}
export function swaggerResponsetNotRequired(target: any, propertyKey: string) {
  Reflect.defineMetadata("responseRequired", false, target, propertyKey);
}
export function swaggerUpdateNotRequired(target: any, propertyKey: string) {
  Reflect.defineMetadata("updateRequired", false, target, propertyKey);
}

//metadata getters
export function getSwagger(target) {
  return Reflect.getMetadata("swagger", target.prototype) ?? false;
}
export function getAuthorization(target) {
  return (
    Reflect.getMetadata("authorization", target.prototype) ?? {
      get: true,
      post: true,
      put: true,
      delete: true,
    }
  );
}

export function getRequestRequired(target, propertyKey) {
  return Reflect.getMetadata("requestRequired", target, propertyKey) ?? true;
}
export function getResponseRequired(target, propertyKey) {
  return Reflect.getMetadata("responseRequired", target, propertyKey) ?? true;
}

export function getUpdateRequired(target, propertyKey) {
  return Reflect.getMetadata("updateRequired", target, propertyKey) ?? true;
}
